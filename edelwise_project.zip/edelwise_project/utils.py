from openpyxl import load_workbook
import os
import pandas as pd

ALLOWED_EXTENSIONS = {'xlsx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def process_file(file_stream):
    try:
        workbook = load_workbook(file_stream, data_only=True)
        sheet = workbook.active
        headers = [
            'Número de Reporte', 'Fecha de Emisión', 'Descripción', 'Identificación', 
            'Peso', 'Dimensiones', 'Forma', 'Transparencia', 'Color', 'Tipo de Color', 
            'Comentario', 'Comentario Especial', 'Origen', 'Historia'
        ]
        data = []
        
        for row in sheet.iter_rows(min_row=2, values_only=True):
            row_data = {headers[i]: value for i, value in enumerate(row)}
            data.append(row_data)
            
        return data
    
    except Exception as e:
        print(f"Error processing file: {e}")
        return None

def obtener_certificados():
    path = 'data.xlsx'  # Ajusta esta ruta si el archivo está en otro lugar
    if not os.path.exists(path):
        print("Archivo no encontrado.")
        return []

    try:
        workbook = load_workbook(path, data_only=True)
        sheet = workbook.active
        headers = [
            'Número de Reporte', 'Fecha de Emisión', 'Descripción', 'Identificación', 
            'Peso', 'Dimensiones', 'Forma', 'Transparencia', 'Color', 'Tipo de Color', 
            'Comentario', 'Comentario Especial', 'Origen', 'Historia'
        ]
        certificados = []

        for row in sheet.iter_rows(min_row=2, values_only=True):
            row_data = {headers[i]: value for i, value in enumerate(row)}
            certificados.append(row_data)
        
        # Verificación adicional de la estructura de los datos
        if not all(isinstance(item, dict) for item in certificados):
            print("La estructura de datos no es correcta.")
            return []

        return certificados
    
    except Exception as e:
        print(f"Error loading certificates: {e}")
        return []

def verificar_duplicados(nuevos_datos, archivo_data='data.xlsx'):
    duplicados = []
    try:
        # Cargar el archivo Excel existente
        df = pd.read_excel(archivo_data)
        numeros_existentes = df['Número de Reporte'].values
        
        # Iterar sobre cada registro nuevo y verificar duplicados
        for registro in nuevos_datos:
            # Asegurar que el registro tenga la clave 'Número de Reporte'
            numero_reporte = registro.get('Número de Reporte')
            if numero_reporte in numeros_existentes:
                duplicados.append(numero_reporte)
                
        return duplicados
    except Exception as e:
        print(f"Error al verificar duplicados: {e}")
        return []