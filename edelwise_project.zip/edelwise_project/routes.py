from flask import Flask, request, render_template, redirect, flash, url_for, session, jsonify
from io import BytesIO
from utils import allowed_file, process_file, verificar_duplicados
import pandas as pd 
import os 
import warnings

# Suprimir el warning específico de openpyxl
warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.secret_key = 'supersecretkey'
app.config['SESSION_TYPE'] = 'filesystem'  # Utilizar el sistema de archivos para la sesión

def configure_routes(app):
    @app.route("/", methods=['GET', 'POST'])
    def upload_file():
        if request.method == 'POST':
            if 'file' not in request.files:
                flash('No file part')
                return redirect(request.url)
            file = request.files['file']
            if file.filename == '':
                flash('No selected file')
                return redirect(request.url)
            if file and allowed_file(file.filename):
                file_stream = BytesIO(file.read())
                preview_data = process_file(file_stream)
                session['preview_data'] = preview_data  # Almacenar preview_data en la sesión
        else:
            session.pop('preview_data', None)  # Limpiar preview_data cuando se carga la página

        # Cargar los certificados desde el archivo Excel
        file_path = 'data.xlsx'
        if os.path.exists(file_path):
            certificados_df = pd.read_excel(file_path)
            certificados = certificados_df.to_dict(orient='records')
        else:
            certificados = []

        preview_data = session.get('preview_data', [])  # Recuperar preview_data de la sesión
        return render_template('index.html', preview_data=preview_data, certificados=certificados)

    @app.route('/certificados')
    def certificados():
        # Cargar los certificados desde el archivo Excel
        file_path = 'data.xlsx'
        if os.path.exists(file_path):
            certificados_df = pd.read_excel(file_path)
            certificados = certificados_df.to_dict(orient='records')
        else:
            certificados = []
        return render_template('todos_certificados.html', certificados=certificados)
   
    @app.route('/get_certificates', methods=['GET'])
    def get_certificates():
        # Leer los datos desde el archivo Excel
        file_path = 'data.xlsx'
        if os.path.exists(file_path):
            certificates_df = pd.read_excel(file_path)
            
            # Reemplazar valores NaN con una cadena vacía o algún valor predeterminado
            certificates_df = certificates_df.fillna('')

            certificates_html = certificates_df.to_html(classes='display table', index=False, header=True, table_id='certificatesTable')
        else:
            certificates_html = '<p>No hay certificados disponibles.</p>'
        
        return jsonify(success=True, html=certificates_html)

    @app.route('/add_order', methods=['POST'])
    def add_order():
        # Recuperar preview_data de la sesión
        preview_data = session.get('preview_data', [])

        # Verificar si hay datos en preview_data
        if preview_data:
            # Definir la ruta del archivo donde se almacenarán los datos
            file_path = 'data.xlsx'

            # Verificar duplicados antes de agregar nuevos datos
            duplicados = verificar_duplicados(preview_data, file_path)
            if duplicados:
                # Devolver un mensaje que liste todos los duplicados encontrados
                return jsonify(success=False, message=f"Los siguientes certificados ya existen: {', '.join(duplicados)}")

            # Convertir los datos de previsualización en un DataFrame de pandas
            new_data_df = pd.DataFrame(preview_data)

            # Verificar si el archivo ya existe
            if os.path.exists(file_path):
                # Leer los datos existentes del archivo
                existing_data_df = pd.read_excel(file_path)
                # Concatenar los datos nuevos con los existentes
                updated_data_df = pd.concat([existing_data_df, new_data_df], ignore_index=True)
            else:
                # Si el archivo no existe, usar solo los datos nuevos
                updated_data_df = new_data_df

            # Guardar los datos actualizados en el archivo Excel
            updated_data_df.to_excel(file_path, index=False)

            # Limpiar preview_data después de añadir la orden
            session.pop('preview_data', None)

            # Devolver una respuesta JSON indicando éxito
            return jsonify(success=True)
        else:
            # Devolver una respuesta JSON indicando que no hay datos para añadir
            return jsonify(success=False, message="No data to add")
