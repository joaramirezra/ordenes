document.addEventListener("DOMContentLoaded", function () {
  console.log("Inicializando DataTables");

  const dataTableOptions = {
    paging: true,
    lengthMenu: [
      [5, 10, 15, 20],
      [5, 10, 15, 20],
    ],
    language: {
      url: "https://cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish.json",
      search: "Buscar:",
      lengthMenu: "Mostrar _MENU_ registros",
      paginate: {
        previous: "<i class='fas fa-chevron-left'></i>",
        next: "<i class='fas fa-chevron-right'></i>",
      },
    },
  };

  function initializeDataTable(selector) {
    if ($.fn.DataTable.isDataTable(selector)) {
      return; // Evita reinicializar una tabla ya inicializada
    }
    $(selector).DataTable(dataTableOptions);
  }

  function ensureDataTablesInitialization() {
    // Asegura la inicialización de las tablas que son cruciales para la funcionalidad desde el inicio
    initializeDataTable("#certificatesTable");
    initializeDataTable("#previewTable");
  }

  // Inicializa DataTables en las tablas visibles
  ensureDataTablesInitialization();

  var addOrderForm = document.getElementById("addOrderForm");
  if (addOrderForm) {
    addOrderForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var form = this;
      var xhr = new XMLHttpRequest();
      xhr.open(form.method, form.action, true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
          if (xhr.status === 200) {
            var response = JSON.parse(xhr.responseText);
            if (response.success) {
              showSuccessMessage("Orden agregada con éxito!");
              reloadCertificates();

              // Limpiar la previsualización después de 3 segundos
              setTimeout(function () {
                clearPreview();
              }, 3000);
            } else {
              showPreviewError(response.message);
            }
          } else {
            showPreviewError(
              "Error al agregar la orden. Por favor, intente nuevamente."
            );
          }
        }
      };
      xhr.send(new URLSearchParams(new FormData(form)).toString());
    });
  }

  function reloadCertificates() {
    console.log("Recargando certificados...");
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/get_certificates", true);
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          try {
            var response = JSON.parse(xhr.responseText);
            console.log("Respuesta del servidor:", response);
            if (response.success) {
              var certificatesTableContainer = document.getElementById(
                "certificatesTableContainer"
              );
              if (certificatesTableContainer) {
                certificatesTableContainer.innerHTML = response.html;
                initializeDataTable("#certificatesTable");
              } else {
                console.error(
                  "Elemento certificatesTableContainer no encontrado."
                );
              }
            } else {
              showPreviewError(
                "Error al actualizar la tabla de certificados: " +
                  response.message
              );
            }
          } catch (e) {
            showPreviewError("Error al procesar la respuesta del servidor.");
          }
        } else {
          showPreviewError(
            "Error al recargar los certificados. Por favor, intente nuevamente."
          );
        }
      }
    };
    xhr.send();
  }

  function showPreviewError(message) {
    var previewCard = document.getElementById("preview-card");
    if (previewCard) {
      // Crear un div de error
      var errorDiv = document.createElement("div");
      errorDiv.className = "alert alert-danger text-center";
      errorDiv.role = "alert";
      errorDiv.innerText = message;

      // Insertar el mensaje de error en la tarjeta de previsualización sin eliminar el contenido
      previewCard.insertBefore(errorDiv, previewCard.firstChild);
    }
  }

  function showSuccessMessage(message) {
    var previewCard = document.getElementById("preview-card");
    if (previewCard) {
      // Crear un div de éxito
      var successDiv = document.createElement("div");
      successDiv.className = "alert alert-success text-center";
      successDiv.role = "alert";
      successDiv.innerText = message;

      // Insertar el mensaje de éxito en la tarjeta de previsualización
      previewCard.innerHTML = ""; // Limpia la tarjeta de previsualización
      previewCard.appendChild(successDiv);
    }
  }

  function clearPreview() {
    var previewCard = document.getElementById("preview-card");
    if (previewCard) {
      previewCard.innerHTML = ""; // Limpia la tarjeta de previsualización después de un éxito
    }
  }
});
